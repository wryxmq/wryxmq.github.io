//随机数
var go0=Math.floor(Math.random()*10+1);
//利用随机数进行跳转,进行负载均衡
if(go0==1){
	window.location.href="http://wryxmq.github.io";
}else if(go0==2){
	window.location.href="http://wryxmq.github.io";
}else if(go0==3){
	window.location.href="http://wryxmq.github.io";
}else if(go0==4){
	window.location.href="http://wryxmq.github.io";
}else if(go0==5){
	window.location.href="http://wryxmq.github.io";
}else if(go0==6){
	window.location.href="http://wryxmq.github.io";
}else if(go0==7){
	window.location.href="http://wryxmq.github.io";
}else if(go0==8){
	window.location.href="http://wryxmq.github.io";
}else if(go0==9){
	window.location.href="http://wryxmq.github.io";
}else if(go0==10){
	window.location.href="http://wryxmq.github.io";
}
