//<script type="text/javascript" src="ifispc.js"></script>
if (/(iPhone|iPad|iPod|iOS|Android)/i.test(navigator.userAgent)) {
    //window.location.href="http://wryxqm.github.io";
}else{
    window.location.href ="http://wryxmq.github.io/ai1";
};
